import re
import string

#Global Data to create list and dictionary for functions to reference
items = open("GroceryList.txt","r")
item_list = items.read().splitlines() #Create readable list with no'/n'
item_list.sort() #Allowed me to make sure i had every item accounted for.
items.close()

#Create quantity of items in dictionary to be referenced for below funtions
Quantity_List = {}
Quantity_List['Apples'] = item_list.count('Apples')
Quantity_List['Beets'] = item_list.count('Beets')
Quantity_List['Broccoli'] = item_list.count('Broccoli')
Quantity_List['Cantaloupe'] = item_list.count('Cantaloupe')
Quantity_List['Cauliflower'] = item_list.count('Cauliflower')
Quantity_List['Celery'] = item_list.count('Celery')
Quantity_List['Cranberries'] = item_list.count('Cranberries')
Quantity_List['Cucumbers'] = item_list.count('Cucumbers')
Quantity_List['Garlic'] = item_list.count('Garlic')
Quantity_List['Limes'] = item_list.count('Limes')
Quantity_List['Onions'] = item_list.count('Onions')
Quantity_List['Peaches'] = item_list.count('Peaches')
Quantity_List['Pears'] = item_list.count('Pears')
Quantity_List['Peas'] = item_list.count('Peas')
Quantity_List['Potatoes'] = item_list.count('Potatoes')
Quantity_List['Pumpkins'] = item_list.count('Pumpkins')
Quantity_List['Radishes'] = item_list.count('Radishes')
Quantity_List['Spinach'] = item_list.count('Spinach')
Quantity_List['Yams'] = item_list.count('Yams')
Quantity_List['Zucchini'] = item_list.count('Zucchini')


def ExitProgram(): # Used to exit the program if user selects to do so.
    print("Thank you, Goodbye")

def DisplayGroceryQuantity(): # Displays each item and the quantity each item appears by referencing the dictionary.
   print('Apples ' + str(Quantity_List['Apples']))
   print('Beets ' + str(Quantity_List['Beets']))
   print('Broccoli ' + str(Quantity_List['Broccoli']))
   print('Cantaloupe ' + str(Quantity_List['Cantaloupe']))
   print('Cauliflower ' + str(Quantity_List['Cauliflower']))
   print('Celery ' + str(Quantity_List['Celery']))
   print('Cranberries ' + str(Quantity_List['Cranberries']))
   print('Cucumbers ' + str(Quantity_List['Cucumbers']))
   print('Garlic ' + str(Quantity_List['Garlic']))
   print('Limes ' + str(Quantity_List['Limes']))
   print('Onions ' + str(Quantity_List['Onions']))
   print('Peaches ' + str(Quantity_List['Peaches']))
   print('Pears ' + str(Quantity_List['Pears']))
   print('Peas ' + str(Quantity_List['Peas']))
   print('Potatoes ' + str(Quantity_List['Potatoes']))
   print('Pumpkins ' + str(Quantity_List['Pumpkins']))
   print('Radishes ' + str(Quantity_List['Radishes']))
   print('Spinach ' + str(Quantity_List['Spinach']))
   print('Yams ' + str(Quantity_List['Yams']))
   print('Zucchini ' + str(Quantity_List['Zucchini']))
   
def DisplayIndividualQuantity(groceryItem): # Received item user selected and returns the quantity to C++
    key = str(groceryItem)
    if key in Quantity_List:
        return Quantity_List[groceryItem]
    else:
        return 0

def CreateHistogramFile(): #Creates file of item and quantity to referenced by C++ code.
   graph = open("frequency.dat", "w")
   graph.write('Apples ' + str(Quantity_List['Apples']))
   graph.write(' Beets ' + str(Quantity_List['Beets']))
   graph.write(' Broccoli ' + str(Quantity_List['Broccoli']))
   graph.write(' Cantaloupe ' + str(Quantity_List['Cantaloupe']))
   graph.write(' Cauliflower ' + str(Quantity_List['Cauliflower']))
   graph.write(' Celery ' + str(Quantity_List['Celery']))
   graph.write(' Cranberries ' + str(Quantity_List['Cranberries']))
   graph.write(' Cucumbers ' + str(Quantity_List['Cucumbers']))
   graph.write(' Garlic ' + str(Quantity_List['Garlic']))
   graph.write(' Limes ' + str(Quantity_List['Limes']))
   graph.write(' Onions ' + str(Quantity_List['Onions']))
   graph.write(' Peaches ' + str(Quantity_List['Peaches']))
   graph.write(' Pears ' + str(Quantity_List['Pears']))
   graph.write(' Peas ' + str(Quantity_List['Peas']))
   graph.write(' Potatoes ' + str(Quantity_List['Potatoes']))
   graph.write(' Pumpkins ' + str(Quantity_List['Pumpkins']))
   graph.write(' Radishes ' + str(Quantity_List['Radishes']))
   graph.write(' Spinach ' + str(Quantity_List['Spinach']))
   graph.write(' Yams ' + str(Quantity_List['Yams']))
   graph.write(' Zucchini ' + str(Quantity_List['Zucchini']))
   graph.close()


    

   
   